import React from "react";
import ReactDOM from "react-dom";

import { TodoList } from "./components/TodoList";

export function App(){
    return (<TodoList/>)
}